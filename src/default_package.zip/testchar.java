
public class testchar {
    public static void main() {
	System.out.println('A');
	System.out.println((int) 'A');
    }

}
