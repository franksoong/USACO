
/*
 * Use the slash-star style comments or the system won't see your identification
 * information
 */

/*
 * The simplest programming challenge is named 'test' 
 * and requires you to read a pair of small integers 
 * from a single input line in the file 'test.in' and 
 * print their sum to the file 'test.out'.
 * 
 * 
 * */

/*
ID: xinkun.2
LANG: JAVA
TASK: test
*/

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.StringTokenizer;

class test {
    public static void main(String[] args) throws IOException {
	// Use BufferedReader rather than RandomAccessFile; it's much faster
	BufferedReader f = new BufferedReader(new FileReader("test.in"));

	// input file name goes above
	PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("test.out")));

	String line = f.readLine(); // 3 4
	StringTokenizer st = new StringTokenizer(line);

	String num1 = st.nextToken(); // 3
	String num2 = st.nextToken(); // 4

	int sum = 0;
	sum = Integer.parseInt(num1) + Integer.parseInt(num2);

	out.println(sum);
	out.close();
	f.close();

	// Use StringTokenizer vs. readLine/split -- lots faster
	// StringTokenizer st = new StringTokenizer(f.readLine());
	//
	// // Get line, break into tokens
	// int i1 = Integer.parseInt(st.nextToken()); // first integer
	// int i2 = Integer.parseInt(st.nextToken()); // second integer

	// out.println(i1 + i2); // output result
	// out.close(); // close the output file
    }
}